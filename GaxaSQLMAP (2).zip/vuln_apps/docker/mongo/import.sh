#!/bin/bash
cat /tmp/mongo.gaxamapsql | mongosh "mongodb://root:prisma@mongo:27017"