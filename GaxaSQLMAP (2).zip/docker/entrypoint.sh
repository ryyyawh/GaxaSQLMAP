#!/bin/ash
python gaxasqlmap.py
